
#include "RSA.h"

/**
 * Sets the key to use
 * @param key - the key to use
 * @return - True if the key is valid and False otherwise
 */
bool RSA_433::setKey(const string& key)
{
	return false;
}

/**	
 * Encrypts a plaintext string
 * @param plaintext - the plaintext string
 * @return - the encrypted ciphertext string
 */
string RSA_433::encrypt(const string& plaintext)
{
	
	return "";
}

/**
 * Decrypts a string of ciphertext
 * @param ciphertext - the ciphertext
 * @return - the plaintext
 */
string RSA_433::decrypt(const string& ciphertext)
{
	return "";
}

